import React from 'react'

const VideoPlayerPage = () => {
    return (
        <div>
            video player
        </div>
    )
}

export default VideoPlayerPage